package exceptions;

/**
 * Student ID: 1910509
 */
// to make clear why an exception is being thrown - the name
// IncorrectManagementRecordStatus is more meaningful in this program
public class IncorrectManagementRecordStatus extends IllegalStateException {
    public IncorrectManagementRecordStatus(String errorMessage) {
        super(errorMessage);
    }
}
