package singleton;

import java.util.HashMap;

/**
 * Student ID: 1910509
 * <p>
 * Create a singleton class for management record status codes, that can be shared amongst other classes.
 * <p>
 * Only need one object/instance of this class which is shared amongst all the classes that need this info.
 * <p>
 * Also makes it easier to change any of the status codes or add new ones
 * when needed
 */

public class ManagementRecordStatusCodes {
    // static variable single_instance of type Singleton
    private static ManagementRecordStatusCodes single_instance = null;

    // variable of type String
    private HashMap<String, Integer> mapStatusCodes = new HashMap<>();

    // private constructor restricted to this class itself
    private ManagementRecordStatusCodes() {
        mapStatusCodes.put("FREE", 0); // Status code: This MR is currently not managing any aircraft information
        mapStatusCodes.put("IN_TRANSIT", 1);
        mapStatusCodes.put("WANTING_TO_LAND", 2);
        mapStatusCodes.put("GROUND_CLEARANCE_GRANTED", 3);
        mapStatusCodes.put("LANDING", 4);
        mapStatusCodes.put("LANDED", 5);
        mapStatusCodes.put("TAXIING", 6);
        mapStatusCodes.put("UNLOADING", 7);
        mapStatusCodes.put("READY_CLEAN_AND_MAINT", 8);
        mapStatusCodes.put("FAULTY_AWAIT_CLEAN", 9);
        mapStatusCodes.put("CLEAN_AWAIT_MAINT", 10);
        mapStatusCodes.put("OK_AWAIT_CLEAN", 11);
        mapStatusCodes.put("AWAIT_REPAIR", 12);
        mapStatusCodes.put("READY_REFUEL", 13);
        mapStatusCodes.put("READY_PASSENGERS", 14);
        mapStatusCodes.put("READY_DEPART", 15);
        mapStatusCodes.put("AWAITING_TAXI", 16);
        mapStatusCodes.put("AWAITING_TAKEOFF", 17);
        mapStatusCodes.put("DEPARTING_THROUGH_LOCAL_AIRSPACE", 18);

    }

    // static method to create instance of Singleton class
    public static ManagementRecordStatusCodes getInstance() {
        if (single_instance == null)
            single_instance = new ManagementRecordStatusCodes();

        return single_instance;
    }

    public int getStatusCode(String s) {
        return mapStatusCodes.get(s);
    }

    // return key that matches the value entered
    public String returnKey(Integer value) {
        return getKey(mapStatusCodes, value);
    }

    // return the associated key for the value in the hashmap
    public <String, Integer> String getKey(HashMap<String, Integer> map, Integer value) {
        for (HashMap.Entry<String, Integer> entry : map.entrySet()) {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }
}
