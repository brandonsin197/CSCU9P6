package singleton;

import java.util.HashMap;

/**
 * Student ID: 1910509
 * <p>
 * Create a singleton class for gate status codes, that can be shared amongst other classes.
 * <p>
 * Only need one object/instance of this class which is shared amongst all the classes that need this info.
 * <p>
 * Also makes it easier to change any of the status codes or add new ones
 * when needed
 */
public class GateStatusCodes {

    // static variable single_instance of type Singleton
    private static GateStatusCodes single_instance = null;

    // variable of type String
    private HashMap<String, Integer> mapStatusCodes = new HashMap<>();

    // private constructor restricted to this class itself
    private GateStatusCodes() {
        mapStatusCodes.put("FREE", 0); // Status code representing the situation when the gate is currently allocated to no aircraft
        mapStatusCodes.put("RESERVED", 1); //Status code representing the situation when the gate has been allocated to an aircraft that has just landed, but the aircraft has not yet docked at the gate
        mapStatusCodes.put("OCCUPIED", 2); // Status code representing the situation when an aircraft is currently at the gate - either unloading passengers, being cleaned and maintained, loading new passengers or finished loading but no permission to taxi to the runway has yet been granted

    }

    // static method to create instance of Singleton class
    public static GateStatusCodes getInstance() {
        if (single_instance == null)
            single_instance = new GateStatusCodes();

        return single_instance;
    }

    public int getStatusCode(String s) {
        return mapStatusCodes.get(s);
    }

    // return key that matches the value entered
    public String returnKey(Integer value) {
        return getKey(mapStatusCodes, value);
    }

    // return the associated key for the value in the hashmap
    public <String, Integer> String getKey(HashMap<String, Integer> map, Integer value) {
        for (HashMap.Entry<String, Integer> entry : map.entrySet()) {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }
}
