package tests;
import entities.Itinerary;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class ItineraryTest {
    private final String from = "Africa";
    private final String to = "STR";
    private final String next = "New York";
    private final Itinerary it = new Itinerary(from,to,next);

    // checks the correct from value was returned
    @Test
    void fromTest(){
        assertEquals(from, it.getFrom(), "Is correct from location");
    }
    // checks the correct to value was returned
    @Test
    void toTest(){
        assertEquals(to, it.getTo(), "Is correct to location");
    }
    // checks the correct next value was returned
    @Test
    void nextTest(){
        assertEquals(next, it.getNext(), "Is correct next location");
    }
}
