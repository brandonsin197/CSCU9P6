package tests;
import entities.Itinerary;
import entities.PassengerDetails;
import entities.PassengerList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class passengerListTest {
    private final PassengerList passengerList = new PassengerList();
    private final PassengerDetails p1 = new PassengerDetails("Garry");
    private final PassengerDetails p2 = new PassengerDetails("Tom");
    private final PassengerDetails p3 = new PassengerDetails("Ted");

    //checks that adding a passenger adds the passenger to the list
    @Test
    void addPassengers(){
        passengerList.addPassenger(p1);
        passengerList.addPassenger(p2);
        passengerList.addPassenger(p3);

        assertEquals(p1, passengerList.getPassenger(0), "returned passenger should match");
        assertEquals(p2, passengerList.getPassenger(1), "returned passenger should match");
        assertEquals(p3, passengerList.getPassenger(2), "returned passenger should match");
    }

    //checks that all passengers where removed from the list
    @Test
    void removePassengers(){
        passengerList.addPassenger(p1);
        passengerList.addPassenger(p2);
        passengerList.addPassenger(p3);


        passengerList.clearPassengerList();
        assertEquals(0, passengerList.getNumberOfPassengers(), "number of passengers should be 0");

    }
    //checks the number of passengers is correct
    @Test
    void getNumberOfPassengers(){
        passengerList.addPassenger(p1);
        passengerList.addPassenger(p2);
        passengerList.addPassenger(p3);


        assertEquals(3, passengerList.getNumberOfPassengers(), "number of passengers should be 3");
    }
}
