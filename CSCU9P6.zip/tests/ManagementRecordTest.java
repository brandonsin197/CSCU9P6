package tests;

import exceptions.IncorrectManagementRecordStatus;
import entities.*;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import singleton.ManagementRecordStatusCodes;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ManagementRecordTest {

    // the list of statusCodes
    ManagementRecordStatusCodes mapStatusCodes = ManagementRecordStatusCodes.getInstance();


    private  int gateNumber = 01;

    // details for flight Transiting through stirling i.e. not landing here
    private  Itinerary i1 = new Itinerary("Toronto", "Paris", null);
    private  String fc1 = "911";
    private  PassengerList passengerList1 = new PassengerList();

    // details for flight landing at stirling
    private  Itinerary i2 = new Itinerary("New York", "STR", "Tokyo");
    private  String fc2 = "111";
    private  PassengerList passengerList2 = new PassengerList();

    // management record containg flight landing at stirling
    private ManagementRecord mrFlightLanding;

    // management record containing flight NOT landing at stirling
    private ManagementRecord mrFlightNotLanding;


    // flight passing through sirling airspace
    private FlightDescriptor flightNotLanding() {
        return new FlightDescriptor(fc1, i1, passengerList1);
    }

    // flight landing at stirling airport
    private FlightDescriptor flightLanding() {
        return new FlightDescriptor(fc2, i2, passengerList2);
    }


    /**
     * create 2 new ManagementRecord's (MR) and pass in FlightDescriptor to each
     * 1/ one MR will hold a FlightDescriptor for a flight landing at Stirling and (mrFlightLanding)
     * 2/ the other a FlightDescriptor for a flight transiting through Stirling airspace (mrFlightNotLanding)
     */
    @BeforeEach
    void before() {
        mrFlightLanding = new ManagementRecord(flightLanding());

        mrFlightNotLanding = new ManagementRecord(flightNotLanding());
    }


    /**
     * get status of the ManagementRecord for mrFlightLanding
     */
    @Test
    void getStatus() {
        // after creating a new ManagementRecord - the initial state must be set to FREE for both records created above
        assertEquals("FREE", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "Initial state of MR is FREE");
        assertEquals("FREE", mapStatusCodes.returnKey(mrFlightNotLanding.getStatus()), "Initial state of MR is FREE");
    }


    /**
     * sets the status for the MR to IN_TRANSIT - i.e. flight is not landing at Stirling
     */
    @Test
    void setStatusForFlightInTransit() {
        // IN_TRANSIT -  i.e. flight is NOT landing here - so set status to IN_TRANSIT
        mrFlightNotLanding.setStatus(mapStatusCodes.getStatusCode("IN_TRANSIT"));
        assertEquals("IN_TRANSIT", mapStatusCodes.returnKey(mrFlightNotLanding.getStatus()), "Is status correct");
    }

    /**
     * the flight landing at stirling has landed and has been cleaned and no fault found
     * so status is not set to READY_REFUEL
     */
    @Test
    void setStatusForFlightLanding() {
       // OK_AWAIT_CLEAN
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("READY_REFUEL"));

        assertEquals("READY_REFUEL", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "Is status correct");
    }

    /**
     * check the flight code is returned correctly for flight not landing at stirling
     * i.e. mrFlightNotLanding ManagementRecord
     */
    @Test
    void getFlightCodeNotLanding() {

        assertEquals(fc1, mrFlightNotLanding.getFlightCode(), "Is correct flight code for flight not landing");
    }

    /**
     * check if flightCode returned correctly for flight landing at stirling
     * i.e. mrFlightLanding ManagementRecord
     */
    @Test
    void getFlightCodeLanding() {

        assertEquals(fc2, mrFlightLanding.getFlightCode(), "Correct flight from MR2");
    }

    /**
     * radar has detected a flight that wants to land at stirling - check status is correctly recorded
     */
    @Test
    void radarDetectLandingFlight() {
        //flight landing at stirling, passed the FlightDescriptor - the status will be checkd
        // it should be free and so will get changed to WANTING_TO_LAND
        mrFlightLanding.radarDetect(flightLanding());
        assertEquals("WANTING_TO_LAND", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "Is the status correctly set to WANTING_TO_LAND");

    }


    /**
     * radar has detected a flight that is NOT landing at stirling - check status is correctly recorded
     */
    @Test
    void radarDetectNotLandingFlight() {

        // check initial status is FREE - before call to radarDetect() method
        assertEquals("FREE", mapStatusCodes.returnKey(mrFlightNotLanding.getStatus()), "Is the status correctly set to IN_TRANSIT");


        //flight NOT landing at stirling, passed the FlightDescriptor - the status will be checked
        // it should be free initially and will now be set to  IN_TRANSIT
         mrFlightNotLanding.radarDetect(flightNotLanding()); // flight descriptor for flight landing at stirling
        assertEquals("IN_TRANSIT", mapStatusCodes.returnKey(mrFlightNotLanding.getStatus()), "Is the status correctly set to IN_TRANSIT");

    }



    @Test
    /**
     * check IncorrectManagementRecordStatus is thrown
     */
    void radarDetectIncorrectFlightDescriptor() {

        // pass in wrong FlightDescriptor
        mrFlightLanding.radarDetect(flightNotLanding());
        assertThrows(IncorrectManagementRecordStatus.class, () -> mrFlightLanding.radarDetect(flightNotLanding()), "Not the correct flight");

    }

    /**
     * when calling radarLostContact - we can be in one of two states:
     * IN_TRANSIT
     * DEPARTING_THROUGH_LOCAL_AIRSPACE
     *
     * afterr the call the ManagementRecord must be cleared and status set to FREE
     */
    @Test
    void radarLostContact() {

        // set status to IN_TRANSIT
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("IN_TRANSIT"));
        assertEquals(mapStatusCodes.getStatusCode("IN_TRANSIT"), mrFlightLanding.getStatus(), "make sure we managed to change status to IN_TRANSIT");

        // We have lost contact with the flight that was IN_TRANSIT
        // therefore the ManagementRecord status should now be FREE
        mrFlightLanding.radarLostContact();

        // check again after method call to make sure the status has been changed from IN_TRANSIT to FREE
        assertEquals(mapStatusCodes.getStatusCode("FREE"), mrFlightLanding.getStatus(), "Testing the radar after the plan has been IN_TRANSIT");


        // set status to DEPARTING_THROUGH_LOCAL_AIRSPACE
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("DEPARTING_THROUGH_LOCAL_AIRSPACE"));
        assertEquals(mapStatusCodes.getStatusCode("DEPARTING_THROUGH_LOCAL_AIRSPACE"), mrFlightLanding.getStatus(), "make sure we managed to change status to DEPARTING_THROUGH_LOCAL_AIRSPACE");

        // We have lost contact with the flight that was IN_TRANSIT
        // therefore the ManagementRecord status should now be FREE
        mrFlightLanding.radarLostContact();

        // check again after method call to make sure the status has been changed from IN_TRANSIT to FREE
        assertEquals(mapStatusCodes.getStatusCode("FREE"), mrFlightLanding.getStatus(), "Testing the radar after the plan has been DEPARTING_THROUGH_LOCAL_AIRSPACE");

    }


    @Test
    /**
     * Should throw the IncorrectManagementRecordStatus if trying to call radarLostContact
     * for a flight that is not transiting through airspace i.e. a flight not in
     * either DEPARTING_THROUGH_LOCAL_AIRSPACE or IN_TRANSIT status
     */
    void radarLostContactNotInTransit() {
        assertThrows(IncorrectManagementRecordStatus.class, () -> mrFlightLanding.radarLostContact(), "Flight is not transiting through airspace");
    }

    /**
     * is status changed successfully after call to taxiTo()
     * and is the gate number updated correctly
     */
    @Test
    void taxiTo() {
        // to satisfy pre-condition set current status to LANDED
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("LANDED"));
        assertEquals("LANDED", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "make sure state changed to LANDED");

        // provide gate to taxi to
        mrFlightLanding.taxiTo(gateNumber);

        // the status should now be TAXIING
        assertEquals("TAXIING", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "call  taxiTo() method and status changed to TAXIING");
        assertEquals(gateNumber, mrFlightLanding.getGateNumber(), "is the gate number correct");
    }


    @Test
    /**
     * Should throw the IncorrectManagementRecordStatus is attempint to call method
     * before status has been set to LANDED
     */
    void taxiToPriorToLanding() {
        assertThrows(IncorrectManagementRecordStatus.class, () -> mrFlightLanding.taxiTo(gateNumber), "trying to allocate a gate prior to status update to LANDED");
    }

    /**
     * Checks if there are some faults faund before or after the Cleaning team has cleaned.
     */
    @Test
    void faultsFound() {
        String description = "FAULT FOUND";

        // set pre condition status
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("READY_CLEAN_AND_MAINT"));
       // check precondition status is correct
        assertEquals("READY_CLEAN_AND_MAINT", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "is pre-condition status correctly set to READY_CLEAN_AND_MAINT");

        // set description - also update status to FAULTY_AWAIT_CLEAN
        mrFlightLanding.faultsFound(description);
        // check the description was set correctly
        assertEquals(description, mrFlightLanding.getFaultDescription(), "was description set correctly");


        // make sure status was updated correctly
        assertEquals("FAULTY_AWAIT_CLEAN", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "status updated to FAULT_AWAIT_CLEAN");

        // change status to CLEAN_AWAIT_MAINT
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("CLEAN_AWAIT_MAINT"));
        // make sure status was set correclty
        assertEquals("CLEAN_AWAIT_MAINT", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "is pre-condition status correctly set to CLEAN_AWAIT_MAINT");

        // this time after we set description the status will change to to AWAIT_REPAIR
        mrFlightLanding.faultsFound(description);

        // make sure status was correcly updated to AWAIT_REPAIR
        assertEquals("AWAIT_REPAIR", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "after setting description is status now AWAIT_REPAIR");

    }


    @Test
    /**
     * thow IncorrectManagementRecordStatus, because our pre-condition is not met w=prior to calling
     * faultsFound() method in ManagementRecords class
     */
    void faultsFoundIncorrectInitialState() {
        String description = "FAULT FOUND";
        assertThrows(IncorrectManagementRecordStatus.class, () -> mrFlightLanding.faultsFound(description), "Attempt to allocate when gate status = reserved, and fails");

    }

    /**
     * are passengers added correctly
     */
    @Test
    void addPassenger() {
        final String p = "passenger one";

        // set correct pre-condition
        mrFlightLanding.setStatus(mapStatusCodes.getStatusCode("READY_PASSENGERS"));
        // make sure status was updated correctly
        assertEquals("READY_PASSENGERS", mapStatusCodes.returnKey(mrFlightLanding.getStatus()), "make sure status is READY_PASSENGERS");

        // add a single passenger to the passenger ArrayList
        mrFlightLanding.addPassenger(new PassengerDetails(p));

        // make sure the passenger was added successfully
        assertEquals(p, mrFlightLanding.getPassengerList().getPassenger(0).getName(), "Passenger1 must match.");


    }


    @Test
    /**
     * Should throw the IncorrectManagementRecordStatus
     * because the pre-condition of status == READY_PASSENGERS is not met
     */
    void addPassengerIncorrectPreCondition() {
        String p = "wrong precondition";

        assertThrows(IncorrectManagementRecordStatus.class, () -> mrFlightLanding.addPassenger(new PassengerDetails(p)), "wrong pre-condition throws IncorrectManagementRecordStatus exception");

    }

    /**
     * Checks if returns the correct list of passengers associate with the flight
     */
    @Test
    void getPassengerList() {
        assertEquals(passengerList2, mrFlightLanding.getPassengerList(), "does passenger list match");

    }

    /**
     * Checks if returns the correct list with passengers
     */
    @Test
    void getPassengerListNotLanding() {
        assertEquals(passengerList1, mrFlightNotLanding.getPassengerList(), "does passenger list match");
    }

    /**
     * Checks if returns the correct itinerary associated with the flight
     */
    @Test
    void getItinerary() {
        assertEquals(i2, mrFlightLanding.getItinerary(), "does itinerary lists match.");
    }


}
