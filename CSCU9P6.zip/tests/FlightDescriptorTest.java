package tests;
import entities.FlightDescriptor;
import entities.Itinerary;
import entities.PassengerList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class FlightDescriptorTest {
    private final Itinerary it = new Itinerary("Florida", "STR", "London");
    private final String flightCode = "2354";
    private final PassengerList passengerList = new PassengerList();
    FlightDescriptor flightDescriptor = new FlightDescriptor(flightCode,it,passengerList);

    // checks that the correct itinerary is returned
    @Test
    void ItineraryTest(){
        assertEquals(it, flightDescriptor.getItinerary(), "Itinerary should match");

    }
    // checks the correct passenger list is returned
    @Test
    void passengerListTest(){
        assertEquals(passengerList, flightDescriptor.getPassengerList(), "Passenger list should match");
    }
    // checks the correct flight code is returned
    @Test
    void flightCodeTest(){
        assertEquals(flightCode, flightDescriptor.getFlightCode(), "FlightCode should match");

    }
}
