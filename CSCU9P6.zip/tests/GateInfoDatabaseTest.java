package tests;

import exceptions.IncorrectManagementRecordStatus;
import models.GateInfoDatabase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import singleton.GateStatusCodes;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @author : 1910509
 */

public class GateInfoDatabaseTest {


    // we have a max of two gates - i.e. array indexes of 0 and 1
    private final int gate1 = 0;
    private final int gate2 = 1;

    private final int mCode1 = 99;
    private final int mCode2 = 11;

    // reference to the GateInfoDatabase
    private GateInfoDatabase gateInfoDatabase;

    // instance of object that holds status codes that a gate can be in
    GateStatusCodes mapStatusCodes = GateStatusCodes.getInstance();

    /**
     * instantiate new gate info database before running each of the tests below
     */
    @BeforeEach
    void before() {
        gateInfoDatabase = new GateInfoDatabase();
    }

    /**
     * We have a max of 2 gates, so if we try to index out of range we get an exception
     */
    @Test
    void getStatusOutOfBounds() {

        /**
         * we have a max of 2 gates, so trying to access a third gate at index 2 should throw an
         * IndexOutOfBoundsException exception
         */
        assertThrows(IndexOutOfBoundsException.class,
                () -> gateInfoDatabase.getStatus(gateInfoDatabase.maxGateNumber),
                "Cannot access more than 2 gates");
    }

    /**
     * make sure each new gate added to array has status of FREE
     */
    @Test
    void initialiseGateArray() {

        /**
         * initilising the gate array should add the 2 gates and set the intial status to FREE
         */
        for (int i = 0; i < gateInfoDatabase.maxGateNumber; i++) {
            assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(i)),
                    "Status should be free for all newly instantiated gates. GATE #: " + i);
        }
    }

    /**
     * check status of first gate, should be set to FREE
     */
    @Test
    void getStatusGateOne() {

        /**
         * the initial status is set to FREE, so calling this method should return status of FREE
         */
        assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(0)),
                "Start status of Gate 1");
    }

    /**
     * check status of second gate, should also be set to FREE
     */
    @Test
    void getStatusGateTwo() {

        /**
         * the initial status is set to FREE, so calling this method should return status of FREE
         */
        assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(1)),
                "Start status of Gate 2");
    }


    /**
     * check that an int array is returned, and is of size 2 and each status is correctly set to FREE
     */
    @Test
    void getStatuses() {
        int[] getStatus = gateInfoDatabase.getStatuses();
        int maxGateNumber = gateInfoDatabase.maxGateNumber;

        /**
         * we have a maximum of 2 gates
         */
        assertEquals(2, getStatus.length, "We get back exactly 2 gates");

        /**
         * when creating a new gate the initial condition should be set to FREE
         */
        for (int i = 0; i < maxGateNumber; i++) {
            assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(i)),
                    "Status should be FREE . GATE #: " + i);
        }
    }

    /**
     * after allocating a gate the status should be changed to RESERVED
     */
    @Test
    void allocate() {

        /**
         * pre-condition for calling reserved is that the current status is FREE, after the call
         * the status is updated to RESERVED
         */
        gateInfoDatabase.allocate(gate1, mCode1);
        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is RESERVED after allocation");
    }

    /**
     * if we try to allocate an already reserved gate,
     * this should throw an IncorrectManagementRecordStatus exception
     */
    @Test
    void allocateAlreadyAllocatedGate() {

        // allocate both gates and set the status on both to RESERVED
        gateInfoDatabase.allocate(gate1, mCode1);
        gateInfoDatabase.allocate(gate2, mCode2);

        // check that the status is correctly set to reserved for both gates:
        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is RESERVED for Gate # 1");

        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate2)),
                "Make sure gate status is RESERVED for Gate # 2");

        // now try and allocate the gate again, this should throw an IncorrectManagementRecordStatus exception
        assertThrows(IncorrectManagementRecordStatus.class, () -> gateInfoDatabase.allocate(gate2, mCode2),
                "Attempt to allocate when gate status = RESERVED, and fails");
    }

    /**
     * when a gate is allocated the status goes to RESERVED, once the
     * flight has docked with the gate the status should change to OCCUPIED
     */
    @Test
    void docked() {

        /**
         * pre-condition for allocating a gate is that the gate is currently in the FREE status.
         * After allocating the gate the status is set to RESERVED.
         */
        gateInfoDatabase.allocate(gate1, mCode1);
        // check the status and make sure it is correctly set to RESERVED
        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is RESERVED");

        /**
         * pre-condition for docking to a gate is that the gate is currently in the RESERVED status.
         * After allocating the gate the status is set to OCCUPIED.
         */
        // now flight has docked - so status should now change to OCCUPIED
        gateInfoDatabase.docked(gate1);
        assertEquals("OCCUPIED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is now OCCUPIED for Gate # 1");

    }

    /**
     * if we try to call docked when the gate has not previously been reserved
     * we get an IncorrectManagementRecordStatus exception
     */
    @Test
    void dockedWhenStatusIsFree() {

        /**
         * pre-condition for the call to docked is that the status is currently set to RESERVED.
         * If this pre-condition is not met then the call will fail and an IncorrectManagementRecordStatus
         * exception will be thrown
         */
        assertThrows(IncorrectManagementRecordStatus.class, () -> gateInfoDatabase.docked(gate1),
                "Cannot dock when status is set to FREE");

        assertThrows(IncorrectManagementRecordStatus.class, () -> gateInfoDatabase.docked(gate2),
                "Cannot dock when status is set to FREE");
    }

    /**
     * after flight has departed the status for the gate is reset to FREE
     */
    @Test
    void departed() {

        /**
         * call allocate method on both gates
         */
        gateInfoDatabase.allocate(gate1, mCode1);
        gateInfoDatabase.allocate(gate2, mCode2);

        /**
         * pre-condition for this method call is that the status is set to FREE, in this case
         * the pre-condition is met, so the status after calling this method is now set to RESERVED
         */
        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is RESERVED (Gate 1)");

        assertEquals("RESERVED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate2)),
                "Make sure gate status is RESERVED (Gate 2)");


        /**
         * call docked method on both gates
         */
        gateInfoDatabase.docked(gate1);
        gateInfoDatabase.docked(gate2);

        /**
         * pre-condition for this method call is that the status is set to RESERVED, in this case
         * the pre-condition is met, so the status after calling this method is now set to OCCUPIED
         */
        assertEquals("OCCUPIED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is now OCCUPIED (Gate 1)");
        assertEquals("OCCUPIED", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate2)),
                "Make sure gate status is now OCCUPIED (Gate 2)");


        /**
         * call departed method on both gates
         */
        gateInfoDatabase.departed(gate1);
        gateInfoDatabase.departed(gate2);

        /**
         * pre-condition for this method call is that the status is set to OCCUPIED, in this case
         * the pre-condition is met, so the status after calling this method is now set to FREE
         */
        assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate1)),
                "Make sure gate status is now FREE for (Gate 1)");
        assertEquals("FREE", mapStatusCodes.returnKey(gateInfoDatabase.getStatus(gate2)),
                "Make sure gate status is now FREE for (Gate 2)");

    }

    /**
     * IncorrectManagementRecordStatus exception when trying to depart a
     * gate that has initial status of FREE
     */
    @Test
    void departedWhenGateIsFree() {

        /**
         * call departed method on both gates - this will throw an IncorrectManagementRecordStatus exception,
         * because the pre-condition for this method call is OCCUPIED. So when pre-condition is not
         * met, an exception if thrown
         *
         */
        assertThrows(IncorrectManagementRecordStatus.class, () -> gateInfoDatabase.departed(gate1),
                "Cannot depart a gate that is at status FREE");

        assertThrows(IncorrectManagementRecordStatus.class, () -> gateInfoDatabase.departed(gate2),
                "Cannot depart a gate that is at status FREE");
    }

}
