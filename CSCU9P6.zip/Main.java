import controllers.*;
import entities.FlightDescriptor;
import entities.Itinerary;
import entities.PassengerDetails;
import entities.PassengerList;
import models.AircraftManagementDatabase;
import models.GateInfoDatabase;
import singleton.ManagementRecordStatusCodes;

/*
  @author Student ID: 1910509
 */

/**
 * The Main class.
 * <p>
 * The principal component is the usual main method required by Java application to launch the application.
 * <p>
 * Instantiates the databases.
 * Instantiates and shows all the system interfaces as Frames.
 *
 */
public class Main {


    static ManagementRecordStatusCodes sc;

    /**
     * Launch SAAMS.
     */

    public static void main(String[] args) {

        sc = ManagementRecordStatusCodes.getInstance();
        // Instantiate databases
        AircraftManagementDatabase aircraftModel = new AircraftManagementDatabase();
        GateInfoDatabase gateInfoDatabase = new GateInfoDatabase();
        // Instantiate and show all interfaces as Frames

        addTestData(aircraftModel);

        // Controllers

        new RadarTransceiver("Radar view", 10, 10, aircraftModel);
        new MaintenanceInspector("Maintenance View", 10, 20, aircraftModel);
        new CleaningSupervisor("Cleaning Supervisor", 10, 30, aircraftModel);
        new RefuellingSupervisor("Refuelling view", 10, 40, aircraftModel);
        new LATC("LATC View", 10, 50, aircraftModel);
        new GOC("GOC", 10, 60, aircraftModel, gateInfoDatabase);
        new PublicInfo("Public Information 1", 20, 20, aircraftModel);
        new PublicInfo("Public Information 2", 20, 40, aircraftModel);
        new GateConsole("Gate Console: ", 20, 60, aircraftModel, gateInfoDatabase, 0);
        new GateConsole("Gate Console: ", 20, 80, aircraftModel, gateInfoDatabase, 0);
        new GateConsole("Gate Console: ", 20, 100, aircraftModel, gateInfoDatabase, 1);

    }


    /**
     * Generate a couple of flights for testing purposes.
     *
     * @param aircraftManagementDatabase database to populate
     */
    private static void addTestData(AircraftManagementDatabase aircraftManagementDatabase) {

        // create list of passengers
        PassengerList list = new PassengerList();

        // need to add passenger details to the list - add 2 passemgers
        list.addPassenger(new PassengerDetails("Passenger One"));
        list.addPassenger(new PassengerDetails("Passenger Two"));
        list.addPassenger(new PassengerDetails("Passenger Three"));
        list.addPassenger(new PassengerDetails("Passenger Four"));


        aircraftManagementDatabase.radarDetect(new FlightDescriptor("EDN111",
                new Itinerary("Edinburgh", "Stirling", "Toronto"),
                list // attach the above list consiting og 2 passengers
        ));

        aircraftManagementDatabase.radarDetect(new FlightDescriptor("STR999",
                new Itinerary("Stirling", "Amsterdam", null),
                new PassengerList() // empty list - no passengers
        ));

        aircraftManagementDatabase.radarDetect(new FlightDescriptor("STR999",
                new Itinerary("New York", "Stirling", null),
                new PassengerList() // empty list - no passengers
        ));

    }

}